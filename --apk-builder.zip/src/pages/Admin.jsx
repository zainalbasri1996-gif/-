export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-[#4CAF50] text-white p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <nav>
            <ul className="flex space-x-4">
              <li><a href="/admin/products" className="hover:underline">Products</a></li>
              <li><a href="/admin/offers" className="hover:underline">Offers</a></li>
              <li><a href="/admin/orders" className="hover:underline">Orders</a></li>
              <li><a href="/admin/reports" className="hover:underline">Reports</a></li>
            </ul>
          </nav>
        </div>
      </header>
      <main className="container mx-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Products</h2>
            <p className="text-gray-700">Manage your product catalog. Add, edit, or remove products as needed.</p>
            <button className="mt-4 bg-[#4CAF50] text-white px-4 py-2 rounded hover:bg-green-600">Manage Products</button>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Offers</h2>
            <p className="text-gray-700">Create and manage special offers and promotions for your products.</p>
            <button className="mt-4 bg-[#4CAF50] text-white px-4 py-2 rounded hover:bg-green-600">Manage Offers</button>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Orders</h2>
            <p className="text-gray-700">View and manage customer orders. Process, ship, or cancel orders as needed.</p>
            <button className="mt-4 bg-[#4CAF50] text-white px-4 py-2 rounded hover:bg-green-600">Manage Orders</button>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Reports</h2>
            <p className="text-gray-700">Generate and view reports on sales, inventory, and other key metrics.</p>
            <button className="mt-4 bg-[#4CAF50] text-white px-4 py-2 rounded hover:bg-green-600">View Reports</button>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
          <ul className="divide-y divide-gray-200">
            <li className="py-4">
              <p className="text-gray-700">New product added: Solar Panel XYZ</p>
              <p className="text-sm text-gray-500">2 hours ago</p>
            </li>
            <li className="py-4">
              <p className="text-gray-700">Order #12345 shipped</p>
              <p className="text-sm text-gray-500">1 day ago</p>
            </li>
            <li className="py-4">
              <p className="text-gray-700">Special offer created: Summer Sale 2023</p>
              <p className="text-sm text-gray-500">3 days ago</p>
            </li>
          </ul>
        </div>
      </main>
    </div>
  );
}