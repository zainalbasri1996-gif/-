export default function DesignSystemPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-gray-900">Design System</h1>
        </div>
      </header>
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Solar System Design</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Solar Panels</h3>
                  <p className="text-gray-700 mb-4">Choose from our selection of high-efficiency solar panels designed for optimal performance in various weather conditions.</p>
                  <button className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                    Browse Panels
                  </button>
                </div>
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Batteries</h3>
                  <p className="text-gray-700 mb-4">Select from our range of lithium-ion batteries that provide reliable energy storage for your solar system.</p>
                  <button className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                    View Batteries
                  </button>
                </div>
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Inverters</h3>
                  <p className="text-gray-700 mb-4">Explore our selection of high-quality inverters designed to convert DC power from your solar panels to AC power for your home.</p>
                  <button className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                    Choose Inverters
                  </button>
                </div>
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Accessories</h3>
                  <p className="text-gray-700 mb-4">Browse our collection of solar accessories, including mounting hardware, cables, and more to complete your solar system.</p>
                  <button className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                    Shop Accessories
                  </button>
                </div>
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">System Design</h3>
                  <p className="text-gray-700 mb-4">Let our experts design a customized solar system tailored to your energy needs and property specifications.</p>
                  <button className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                    Get a Design
                  </button>
                </div>
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Component List & Cost</h3>
                  <p className="text-gray-700 mb-4">Generate a detailed list of components and estimate the total cost for your solar system based on your design choices.</p>
                  <button className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                    Calculate Cost
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}