export default function ProductDetails() {
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="md:w-1/2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img
                src="https://via.placeholder.com/600x400"
                alt="Product Image"
                className="w-full h-auto"
              />
            </div>
            <div className="grid grid-cols-4 gap-2 mt-4">
              {[1, 2, 3, 4].map((item) => (
                <div key={item} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <img
                    src={`https://via.placeholder.com/150x150?text=Thumbnail+${item}`}
                    alt={`Product Thumbnail ${item}`}
                    className="w-full h-auto"
                  />
                </div>
              ))}
            </div>
          </div>
          <div className="md:w-1/2">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h1 className="text-3xl font-bold text-gray-800 mb-4">Solar Panel System</h1>
              <div className="flex items-center mb-4">
                <div className="flex items-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg
                      key={star}
                      className="w-5 h-5 text-yellow-500 fill-current"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                    >
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                    </svg>
                  ))}
                </div>
                <span className="ml-2 text-gray-600">(4.5)</span>
              </div>
              <p className="text-gray-700 mb-6">
                Our high-efficiency solar panel system is designed to maximize energy production while minimizing space requirements.
                Featuring advanced monocrystalline solar cells and a durable, lightweight frame, this system is perfect for residential and
                commercial applications. With a 25-year warranty and easy installation, our solar panels provide a reliable and cost-effective
                solution for your energy needs.
              </p>
              <div className="flex items-center mb-6">
                <span className="text-2xl font-bold text-gray-800 mr-2">$999.99</span>
                <span className="text-gray-500 line-through">$1,299.99</span>
              </div>
              <div className="flex items-center mb-6">
                <span className="text-gray-700 mr-4">Quantity:</span>
                <div className="flex items-center border rounded">
                  <button className="px-3 py-1 border-r">-</button>
                  <span className="px-4 py-1">1</span>
                  <button className="px-3 py-1 border-l">+</button>
                </div>
              </div>
              <div className="flex gap-4">
                <button className="bg-[#4CAF50] text-white px-6 py-3 rounded-lg hover:bg-green-600 transition-colors">
                  Add to Cart
                </button>
                <button className="border border-[#4CAF50] text-[#4CAF50] px-6 py-3 rounded-lg hover:bg-gray-100 transition-colors">
                  Buy Now
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Product Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">Specifications</h3>
              <ul className="list-disc pl-5 space-y-2 text-gray-600">
                <li>Type: Monocrystalline Solar Panel</li>
                <li>Power Output: 400W</li>
                <li>Efficiency: 20.5%</li>
                <li>Dimensions: 65.3" x 39.4" x 1.6"</li>
                <li>Weight: 38.5 lbs</li>
                <li>Warranty: 25 years</li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">Features</h3>
              <ul className="list-disc pl-5 space-y-2 text-gray-600">
                <li>High-efficiency monocrystalline solar cells</li>
                <li>Durable, lightweight aluminum frame</li>
                <li>Easy installation with pre-drilled mounting holes</li>
                <li>IP68 water and dust resistant rating</li>
                <li>Compliant with UL 1703 and IEC 61215 standards</li>
                <li>25-year product and performance warranty</li>
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Customer Reviews</h2>
          <div className="space-y-6">
            {[1, 2, 3].map((review) => (
              <div key={review} className="border-b pb-6 last:border-b-0 last:pb-0">
                <div className="flex items-center mb-2">
                  <div className="w-10 h-10 rounded-full bg-gray-300 mr-3"></div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Customer {review}</h3>
                    <div className="flex items-center">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <svg
                          key={star}
                          className={`w-4 h-4 ${star <= review + 1 ? 'text-yellow-500' : 'text-gray-300'} fill-current`}
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 20 20"
                        >
                          <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                        </svg>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">
                  {`This solar panel system has exceeded my expectations. The installation was straightforward, and the energy savings have been significant.
                  I highly recommend this product to anyone looking to go solar.`}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}