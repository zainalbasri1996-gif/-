export default function Cart() {
  const [cartItems, setCartItems] = React.useState([
    { id: 1, name: 'Product 1', price: 10.99, quantity: 2 },
    { id: 2, name: 'Product 2', price: 20.99, quantity: 1 },
    { id: 3, name: 'Product 3', price: 15.99, quantity: 3 },
  ]);

  const handleQuantityChange = (id, newQuantity) => {
    setCartItems(cartItems.map(item =>
      item.id === id ? { ...item, quantity: newQuantity } : item
    ));
  };

  const handleRemoveItem = (id) => {
    setCartItems(cartItems.filter(item => item.id !== id));
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2);
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-semibold mb-6 text-center text-gray-800">Shopping Cart</h1>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="md:w-3/4">
            <div className="bg-white rounded-lg shadow-md p-6 mb-4">
              <table className="w-full">
                <thead>
                  <tr>
                    <th className="text-left font-semibold text-gray-700">Product</th>
                    <th className="text-left font-semibold text-gray-700">Price</th>
                    <th className="text-left font-semibold text-gray-700">Quantity</th>
                    <th className="text-left font-semibold text-gray-700">Total</th>
                    <th className="text-left font-semibold text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {cartItems.map(item => (
                    <tr key={item.id} className="border-b border-gray-200">
                      <td className="py-4">
                        <div className="flex items-center">
                          <img className="h-16 w-16 mr-4" src={`https://via.placeholder.com/150?text=${item.name}`} alt={item.name} />
                          <span className="font-medium text-gray-800">{item.name}</span>
                        </div>
                      </td>
                      <td className="py-4">${item.price.toFixed(2)}</td>
                      <td className="py-4">
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value))}
                          className="w-16 border rounded px-2 py-1"
                        />
                      </td>
                      <td className="py-4">${(item.price * item.quantity).toFixed(2)}</td>
                      <td className="py-4">
                        <button
                          onClick={() => handleRemoveItem(item.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="md:w-1/4">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold mb-4 text-gray-800">Summary</h2>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Subtotal</span>
                <span className="text-gray-900">${calculateTotal()}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Taxes</span>
                <span className="text-gray-900">${(calculateTotal() * 0.1).toFixed(2)}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Shipping</span>
                <span className="text-gray-900">$5.00</span>
              </div>
              <hr className="my-2" />
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-gray-900">Total</span>
                <span className="font-semibold text-gray-900">${(parseFloat(calculateTotal()) + parseFloat(calculateTotal()) * 0.1 + 5).toFixed(2)}</span>
              </div>
              <button className="bg-[#4CAF50] text-white py-2 px-4 rounded-lg mt-4 w-full hover:bg-[#3d8b40]">
                Checkout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}