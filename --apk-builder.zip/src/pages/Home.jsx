export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Hero Section */}
      <section className="bg-green-600 text-white py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold mb-4">مرحبًا بكم في منصتنا الشمسية</h1>
          <p className="text-xl mb-8">تجربة مستخدم رائعة لتصميم منظوماتك الشمسية</p>
          <button className="bg-white text-green-600 font-bold py-2 px-6 rounded-lg hover:bg-green-100 transition duration-300">
            استكشف المنتجات
          </button>
        </div>
      </section>

      {/* Main Products Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-800 mb-12 text-center">منتجاتنا الرئيسية</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Product Card 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-green-100 p-6">
                <h3 className="text-xl font-semibold text-green-800 mb-2">المنتج 1</h3>
                <p className="text-gray-600">وصف مختصر للمنتج الأول مع ميزات رئيسية.</p>
              </div>
              <div className="p-6">
                <p className="text-gray-700 mb-4">وصف تفصيلي للمنتج الأول مع ميزات إضافية.</p>
                <button className="text-green-600 font-medium hover:underline">
                  تعرف على المزيد
                </button>
              </div>
            </div>

            {/* Product Card 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-green-100 p-6">
                <h3 className="text-xl font-semibold text-green-800 mb-2">المنتج 2</h3>
                <p className="text-gray-600">وصف مختصر للمنتج الثاني مع ميزات رئيسية.</p>
              </div>
              <div className="p-6">
                <p className="text-gray-700 mb-4">وصف تفصيلي للمنتج الثاني مع ميزات إضافية.</p>
                <button className="text-green-600 font-medium hover:underline">
                  تعرف على المزيد
                </button>
              </div>
            </div>

            {/* Product Card 3 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-green-100 p-6">
                <h3 className="text-xl font-semibold text-green-800 mb-2">المنتج 3</h3>
                <p className="text-gray-600">وصف مختصر للمنتج الثالث مع ميزات رئيسية.</p>
              </div>
              <div className="p-6">
                <p className="text-gray-700 mb-4">وصف تفصيلي للمنتج الثالث مع ميزات إضافية.</p>
                <button className="text-green-600 font-medium hover:underline">
                  تعرف على المزيد
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Special Offers Section */}
      <section className="bg-green-50 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-800 mb-12 text-center">عروض خاصة</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Offer Card 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-green-200 p-6">
                <h3 className="text-xl font-semibold text-green-800 mb-2">عرض خاص 1</h3>
                <p className="text-gray-600">وصف مختصر للعرض الخاص الأول.</p>
              </div>
              <div className="p-6">
                <p className="text-gray-700 mb-4">وصف تفصيلي للعرض الخاص الأول مع تفاصيل إضافية.</p>
                <button className="bg-green-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-700 transition duration-300">
                  استغل العرض
                </button>
              </div>
            </div>

            {/* Offer Card 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-green-200 p-6">
                <h3 className="text-xl font-semibold text-green-800 mb-2">عرض خاص 2</h3>
                <p className="text-gray-600">وصف مختصر للعرض الخاص الثاني.</p>
              </div>
              <div className="p-6">
                <p className="text-gray-700 mb-4">وصف تفصيلي للعرض الخاص الثاني مع تفاصيل إضافية.</p>
                <button className="bg-green-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-700 transition duration-300">
                  استغل العرض
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">من نحن</h2>
          <div className="bg-white rounded-lg shadow-md p-8">
            <p className="text-gray-700 mb-4">
              نحن شركة رائدة في مجال تصميم منظومات الطاقة الشمسية، نقدم حلولًا مبتكرة وفعالة لتلبية احتياجات عملائنا في جميع أنحاء العالم.
            </p>
            <p className="text-gray-700 mb-4">
              مع سنوات من الخبرة في هذا المجال، نحن ملتزمون بتقديم منتجات عالية الجودة وخدمات استثنائية لعملائنا.
            </p>
            <p className="text-gray-700">
              نحن نؤمن بأن الطاقة النظيفة هي المستقبل، ونحن ملتزمون بتقديم حلول الطاقة الشمسية التي تساهم في حماية البيئة وتوفير الطاقة.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}