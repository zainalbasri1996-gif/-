export default function StorePage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-[#4CAF50] text-white p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">Solar Store</h1>
          <nav>
            <ul className="flex space-x-4">
              <li><a href="/" className="hover:underline">Home</a></li>
              <li><a href="/store" className="font-bold">Store</a></li>
              <li><a href="/about" className="hover:underline">About</a></li>
              <li><a href="/contact" className="hover:underline">Contact</a></li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        <h2 className="text-3xl font-semibold mb-6">Our Solar Products</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Solar Panels */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <img src="https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="Solar Panels" className="w-full h-48 object-cover" />
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-2">Solar Panels</h3>
              <p className="text-gray-600 mb-4">High-efficiency solar panels for residential and commercial use.</p>
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-[#4CAF50]">$299.99</span>
                <button className="bg-[#4CAF50] text-white px-4 py-2 rounded hover:bg-green-600 transition-colors duration-300">Add to Cart</button>
              </div>
            </div>
          </div>

          {/* Batteries */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <img src="https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="Batteries" className="w-full h-48 object-cover" />
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-2">Batteries</h3>
              <p className="text-gray-600 mb-4">Reliable energy storage solutions for your solar system.</p>
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-[#4CAF50]">$499.99</span>
                <button className="bg-[#4CAF50] text-white px-4 py-2 rounded hover:bg-green-600 transition-colors duration-300">Add to Cart</button>
              </div>
            </div>
          </div>

          {/* Inverters */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <img src="https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="Inverters" className="w-full h-48 object-cover" />
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-2">Inverters</h3>
              <p className="text-gray-600 mb-4">High-performance inverters to convert DC to AC power.</p>
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-[#4CAF50]">$199.99</span>
                <button className="bg-[#4CAF50] text-white px-4 py-2 rounded hover:bg-green-600 transition-colors duration-300">Add to Cart</button>
              </div>
            </div>
          </div>

          {/* Accessories */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <img src="https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="Accessories" className="w-full h-48 object-cover" />
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-2">Accessories</h3>
              <p className="text-gray-600 mb-4">Essential accessories for your solar system setup.</p>
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-[#4CAF50]">$49.99</span>
                <button className="bg-[#4CAF50] text-white px-4 py-2 rounded hover:bg-green-600 transition-colors duration-300">Add to Cart</button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-[#4CAF50] text-white p-4 mt-8">
        <div className="container mx-auto text-center">
          <p>&copy; 2023 Solar Store. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}