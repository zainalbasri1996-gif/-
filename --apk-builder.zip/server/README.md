# Backend

Generated stub for solar-energy-platform. Run with `node server/index.js` after wiring an Express server.